/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;
import java.util.*;
/**
 *
 * @author H.K.S Nonis
 */
public class Receipt {
    String transactionID;
    String supplier;
    Date date;
    String time;
    
    
    public Receipt(String transactionID, String supplier, Date date, String time)
    {
        this.transactionID=transactionID;
        this.supplier=supplier;
        this.date=date;
        this.time=time;
    
    }
   static double getUnitPrice(double unitPrice)
    {
        double unit_price=unitPrice;
        return unit_price;
    }
    static double getDiscount(double discount)
    {
        double discount1 =discount;
        return discount1;
    }
    static Date getDate()
    {
      Date current = new Date(); 
      return current;
    }
    static String getItemName(String name)
    {
        String itemName = name;
        return itemName;
    }
    
    static String getItemNo(String itemNo)
    {
        String item_No = itemNo;
        return item_No;
    }
    
    static int getQuantity(int quantity)
    {
        int Quantity = quantity;
        return Quantity;
    }
    
    
    double calPricePerItem(int quantity, double unitPrice )
    {
        double cost=quantity*unitPrice;
        return cost;
    }
    
    double calTotalAmount(double cost, double discount)
    {
        double tot=cost-(cost*(discount/100.00));
        return tot;
    }
    
}

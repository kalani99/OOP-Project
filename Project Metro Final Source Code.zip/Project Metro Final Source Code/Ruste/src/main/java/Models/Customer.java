/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *IT20266264
 *
 */
public class Customer {
    String NIC;
    String Name;
    String Address;
    String Email;
    String Phone;
    
    //constructor
    public Customer(String NIC, String name, String address, String email, String Phone)
    {
        this.NIC=NIC;
        this.Name=name;
        this.Address=address;
        this.Email=email;
        this.Phone=Phone;
    }
    
    
    
    
}

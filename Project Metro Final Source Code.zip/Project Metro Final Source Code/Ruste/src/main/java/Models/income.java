/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;
import java.util.*;
/**
 *
 * @author H.K.S Nonis
 */
public class income {
    String incomeID;
    double sales;
    double discountReceived;
    double otherincome;
    String month;
    int year;
    double totalIncome;
    
    public income(String incomeID, double sales, double discountReceived, double otherincome, String month, int year, double totalIncome)
    {
        this.incomeID=incomeID;
        this.sales=sales;
        this.discountReceived=discountReceived;
        this.otherincome=otherincome;
        this.month=month;
        this.year=year;
        this.totalIncome=totalIncome;
    }
    static double discountRcd(double discount)
    {
        Double Discount=discount;
        return Discount;
    }
    static double calculateSales(double unitPrice, int quantity, double discount)
    {
        double tot=unitPrice*quantity;
        double dis=discountRcd(discount);
        double total=tot*(dis/100.00);
        return total;
    }

    static double calOtherIncome(double other)
    {
        double otherIncome=other;
        return otherIncome;
    }
}

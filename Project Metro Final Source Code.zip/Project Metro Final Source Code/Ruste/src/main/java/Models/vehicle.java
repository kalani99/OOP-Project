/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author H.K.S Nonis
 */
public class vehicle {
    String reg_no;
    String brand;
    String model;
    String fuel;
    String year_made;
    String year_reg;
    String engine_no;
    String chassis_no;
    String colour;
    String license_expiry_date;
    String  OwnerNIC;
    public vehicle(String reg_no, String year_reg, String engine_no, String colour, String make, String year_made, String fuel, String chassis_no, String type, String license_expiry_date, String OwnerNIC)
    { 
        this.reg_no=reg_no;
        this.brand=make;
        this.model=type;
        this.fuel=fuel;
        this.year_made=year_made;
        this.year_reg=year_reg;
        this.engine_no=engine_no;
        this.chassis_no=chassis_no;
        this.colour=colour;
        this.license_expiry_date=license_expiry_date;
        this.OwnerNIC=OwnerNIC;
        
    }
    
}



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author H.K.S Nonis
 */
public class tech_emp {
    //from repair and restore jobs
    String EID;
    String name;
    String NIC;
    String DOB;
    String address;
    String phone;
    String specialty;
    String qualifications;
    double salary;
    String email;
    double yrs_of_experience;
    
    public tech_emp(String EID, String name, String NIC, String DOB, String address, String phone, String specialty, String qualifications, double salary, String email, double yrs_of_experience)
    {
        this.EID=EID;
        this.name=name;
        this.NIC=NIC;
        this.DOB=DOB;
        this.address=address;
        this.phone=phone;
        this.specialty=specialty;
        this.qualifications=qualifications;
        this.salary=salary;
        this.email=email;
        this.yrs_of_experience=yrs_of_experience;
    }
  
    
   
}

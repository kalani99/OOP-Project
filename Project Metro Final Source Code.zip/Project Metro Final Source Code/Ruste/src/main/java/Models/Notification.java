/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author H.K.S Nonis
 */
public class Notification {
    String email;
    
    
    public class NotificationCustomer extends Notification{
        
        String jobID;
        String vehicle_reg_no;
        String status;
        String CusName;
        
        public NotificationCustomer(String jobID, String vehicle_reg_no, String status, String CusName) {
          
          this.jobID=jobID;
           this.vehicle_reg_no=vehicle_reg_no;
           this.status=status;
           this.CusName=CusName;
           this.email=email;
        }
        
    }
    
   public class NotificationSupplier extends Notification{
        
        String content;
        
        public NotificationSupplier(String content) {
          
          this.content=content;
          this.email=email;
        }
        
    }
    
    
    
    
    
}

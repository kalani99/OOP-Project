/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author H.K.S Nonis
 */
public class seriviceManager {
    
    String EID;
    String name;
    String NIC;
    String address;
    String phone;
    String email;
    String DOB;
    double salary;
    String specialty;
    double yrs_of_experience;
    String qualifications;
    
    public seriviceManager(String EID, String name, String NIC, String address, String phone, String email, String DOB, double salary, String specialty, double yrs_of_experience, String qualifications )
    {
    this.EID=EID;
    this.name=name;
    this.NIC=NIC;
    this.address=address;
    this.phone=phone;
    this.email=email;
    this.DOB=DOB;
    this.salary=salary;
    this.specialty=specialty;
    this.yrs_of_experience=yrs_of_experience;
    this.qualifications=qualifications;
    }
    
    
   
  
    static String[] allocateEmp(String EID, String description, String jobID)
    {
        
        String [] job = {description, jobID, EID};
        return job;
    }
    
    static String[] receiveJobDescription(String EID, String description, String jobID, String vehicle_no)
    {
        String[] job_description = {EID, description, jobID, vehicle_no};
        return job_description;
    }
    
    
}

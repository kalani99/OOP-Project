



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author H.K.S Nonis
 */
public class SpareParts {
    String SID;
    String brand;
    double price;
    int quantity;
    String country_made;
    String  type;
    
    public SpareParts(String SID, String brand, double price, int quantity, String country_made, String type)
    {
        this.SID=SID;
        this.brand=brand;
        this.price=price;
        this.quantity=quantity;
        this.country_made=country_made;
        this.type=type;
    }
    
}

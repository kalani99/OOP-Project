 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;
/**
 *
 * @author H.K.S Nonis
 */
public class receptionist {
    String name;
    String EID;
    String address;
    String phone;
    String email;
    String NIC;
    String DOB;
    double salary;
    
    //constructor
    public receptionist( String name, String EID, String address, String phone, String email, String NIC, String DOB, double salary)
    {
        this.name=name;
        this.EID=EID;
        this.address=address;
        this.phone=phone;
        this.email=email;
        this.NIC=NIC;
        this.DOB=DOB;
        this.salary=salary;
    }
    
    
    
      
    
    static String[] addCustomerDetails(String NIC, String name, String address, String email, String Phone)
    {
       String[] details = {NIC, name, address, email, Phone};
       return details;
    }
    
    static String[] notifyMechanic(String jobID, String reg_no, String NIC, String date)
    {
        String[] details10 = {jobID, reg_no, NIC, date};
        return details10;
    }
    
    static String[] addRestoreJob(String jobID, String reg_no, String NIC, String date)
    {
        String[] details7 = {jobID, reg_no, NIC, date};
        return details7;
    }
    
    static String[] updateRestoreJob(String jobID, String reg_no, String NIC, String date)
    {
        String[] details8 = {jobID, reg_no, NIC, date};
        return details8;
    }
    
    void deleteRestoreJob(String jobID,  String reg_no, String NIC, String date)
    {
        String[] delete = {jobID, reg_no, NIC, date};
        delete=null;
    }
    
    static String[] addRepairJob(String jobID, String reg_no, String NIC, String date)
    {
        String[] details2 = {jobID, reg_no, NIC, date};
        return details2;
    }
    
    static String[] updateRepairJob(String jobID, String reg_no, String NIC, String date)
    {
        String[] details1={jobID, reg_no, NIC, date};
        return details1;
    }
    
    void  deleteRepairJob(String jobID, String reg_no, String NIC, String date)
    {
        String[] delete1 = {jobID, reg_no, NIC, date};
        delete1=null;
    }

    static double calculateIncome(double sales, double discountRcd, double other_income)
    {
        double income = sales+discountRcd+other_income;
        return income;
    }
    
    static double calculateExpense(double salary, double utilities, double food, double rent, double maintenance, double taxes, double payStock, double advertising, double business_fees, double equipment, double insurance, double misc)
    {
        double expenses = rent+salary+utilities+maintenance+food+taxes+payStock+advertising+business_fees+equipment+insurance+misc;
        return expenses;
        
    }
    
    static String[] createReport(String reportID, String month, String year, String date, String incomeID, String expenseID, double income, double expenses, double capital, double profit)
    {
        String i=String.valueOf(income);
        String e=String.valueOf(expenses);
        String c=String.valueOf(capital);
        String p=String.valueOf(profit);
        String[] report = {reportID, month, year, date, incomeID, expenseID, i,e,c,p};
        return report;
    }
    
   
    static String[] addSupplier(String supID, String name, String address, String phone, String email)
    {
       String[] details4 = {supID, name, address, phone, email};
       return details4;
    }
    
    
    static String[] updateSupplier(String supID, String name, String address, String phone, String email)
    {
       String[] details3 = {supID, name, address, phone, email};
       return details3;
    }
    
    void deleteSupplier(String supID, String name, String address, String phone, String email)
            
    {
      
        String[] delete3 = {supID, name, address, phone, email};
        delete3=null;
    }
    
    //addSupplies, updateSupplies, deleteSupplies are same as addParts, updateParts, deleteParts
    static String[] addSupplies(String SID, String brand, double price, int quantity, String country_made, String type)
    {
        String x=String.valueOf(price);
        String y=Integer.toString(quantity);
        String[] details5 = {SID, brand, x, y, country_made, type};
        return details5;
    }
    
    static  String[] updateSupplies(String SID, String brand, double price, int quantity, String country_made, String type)
    {
        String a=String.valueOf(price);
        String b=Integer.toString(quantity);
        String[] details6 = {SID, brand, a, b, country_made, type};
        return details6;
        
    }
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author H.K.S Nonis
 */
public class expense {
    String expenseID;
    String month;
    String year;
    double rent;
    double salary;
    double utility;
    double maintenance;
    double food;
    double taxes;
    double pay_stock;
    double advertising;
    double business_fees;
    double equipment;
    double insurance;
    double miscellaneous;
    double total;
    
    public expense(String expenseID, String month, String year, double rent, double salary, double utility, double maintenance, double food, double taxes, double pay_stock, double advertising, double business_fees, double equipment, double transport, double insurance, double miscellaneous, double total)
    {
        this.expenseID=expenseID;
        this.month=month;
        this.year=year;
        this.rent=rent;
        this.salary=salary;
        this.utility=utility;
        this.maintenance=maintenance;
        this.food=food;
        this.taxes=taxes;
        this.pay_stock=pay_stock;
        this.advertising=advertising;
        this.business_fees=business_fees;
        this.equipment=equipment;
        this.insurance=insurance;
        this.miscellaneous=miscellaneous;
        this.total=total;
    }
    
    static double calSalary(double salary)
    {
        double Salary=salary;
        return salary;
    }
    
    static double calUtilities(double utilities)
    {
        double util=utilities;
        return util;
    }
    
    static double calMaintenanceFees(double fees)
    {
        double main_fees=fees;
        return main_fees;
    }
    
    static double foodCharges(double food)
    {
        double food_charges=food;
        return food_charges;
    }
    
    static double calTaxes(double taxes)
    {
        double Taxes=taxes;
        return Taxes;
    }
    
    static double calCharges(double charges)
    {
        double Charges=charges;
        return Charges;
    }
    
    static double calMiscellaneous(double misc)
    {
        double Misc=misc;
        return Misc;
    }
    
   static double calStockPayments(double stock)
    {
        double Stock=stock;
        return Stock;
    }
    
}
 

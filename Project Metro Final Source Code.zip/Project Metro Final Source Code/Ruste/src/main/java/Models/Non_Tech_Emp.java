/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author H.K.S Nonis
 */
public class Non_Tech_Emp {
    String EID;
    String name;
    String NIC;
    String DOB;
    String address;
    String phone;
    String specialty;
    String qualifications;
    double salary;
    String email;
    
   
    public Non_Tech_Emp(String EID, String name, String NIC, String DOB, String address, String phone, String specialty, String qualifications, double salary, String email)
    {
        this.EID=EID;
        this.name=name;
        this.NIC=NIC;
        this.DOB=DOB;
        this.address=address;
        this.phone=phone;
        this.specialty=specialty;
        this.qualifications=qualifications;
        this.salary=salary;
        this.email=email;
    }
    
    
}

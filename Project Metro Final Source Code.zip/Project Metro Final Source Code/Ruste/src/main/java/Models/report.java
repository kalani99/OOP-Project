/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;
import java.util.*;
/**
 *
 * @author H.K.S Nonis
 */
public class report {
    String reportID;
    String month;
    int year;
    String incomeID;
    String expenseID;
    double income; 
    double expense;
    double capital;
    Date date;
    double profit;
    
    public report(String reportID, String month, int year, String incomeID, String expenseID, double income, double expense, double capital, Date date, double profit)
    {
        this.reportID=reportID;
        this.month=month;
        this.year=year;
        this.incomeID=incomeID;
        this.expenseID=expenseID;
        this.income=income;
        this.expense=expense;
        this.capital=capital;
        this.date=date;
        this.profit=profit;
    }
    
    static double calProfit(double income, double expense)
    {
        double profit=income-expense;
        return profit;
    }
}

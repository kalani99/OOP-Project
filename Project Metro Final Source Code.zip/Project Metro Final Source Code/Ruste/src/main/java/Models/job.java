/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;
/**
 *
 * @author H.K.S Nonis
 */
public class job {
    String jobID;
    String Mec_EID;
    String Cus_NIC;
    String Veh_reg_no;
    String listOfRepairs;
    
    public job(String jobID, String Mec_EID, String Cus_NIC, String Veh_reg_no, String listOfRepairs)
    {
        this.jobID=jobID;
        this.Mec_EID=Mec_EID;
        this.Cus_NIC=Cus_NIC;
        this.Veh_reg_no=Veh_reg_no;
        this.listOfRepairs=listOfRepairs;
       
   
    }
    void getjobID(String jobID)
    {
       String job_ID=jobID;
    }
    
    void getCusNIC(String NIC)
    {
        String NIC_No=NIC;
    }
    void getVehRegNO(String reg_no)
    {
        String regNo=reg_no;
    }
}

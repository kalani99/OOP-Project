create database ruste
use ruste
create table vehicle(
reg_no varchar(20) primary key,
reg_year date,
year_made date,
engine_no varchar(40),
chassis_no varchar(40),
color varchar(30),
fuel varchar(30),
brand varchar(30),
model varchar(30),
license_expire_date date,
Owner_NIC varchar(15),
constraint vehicle_owner_fk foreign key(Owner_NIC) references vehicle_owner(NIC)
)




create table vehicle_owner(
NIC varchar(15) primary key,
name varchar(50),
phone varchar(40),
address varchar(40), 
email varchar(40)
)


create table spareparts(
SID varchar(20) primary key,
brand varchar(30),
unit_price real,
quantity int,
country_made varchar(20),
type varchar(20),
supID varchar(20),
constraint suppliers_fk foreign key(supID) references suppliers(supID)
)

create table non_tech_emp(
EID varchar(20) primary key,
name varchar(30),
address varchar(40),
phone varchar(20),
NIC varchar(20),
dob date,
email varchar(20),
specialty varchar(30),
qualification varchar(40),
salary real
)

create table tech_emp(
EID varchar(20) primary key,
name varchar(30),
address varchar(40),
phone varchar(20),
NIC varchar(20),
dob date,
email varchar(20),
specialty varchar(30),
qualification varchar(40),
yrs_of_experience int,
salary real
)

create table suppliers(
supID varchar(20) primary key,
name varchar(30),
address varchar(50),
phone varchar(50),
email varchar(40)
)

create table job(
jobID varchar(20) primary key,
customerNIC varchar(15),
vehicle_no varchar(20),
tentative_date_of_completion date,
constraint vehicle_owner_fk1 foreign key(customerNIC) references vehicle_owner(NIC),
constraint vehicle_fk foreign key(vehicle_no) references vehicle(reg_no)
)
alter table job 
add type varchar(20)



create table jobs_to_be_done(
jobID varchar(20),
EID varchar(20),
status varchar(20),
Job varchar(40),
constraint jobs_to_be_done_pk primary key(jobID, EID),
constraint job_fk foreign key(jobID) references job(jobID),
constraint tech_emp_kf foreign key(EID) references tech_emp(EID)
)


create table income(
incomeID varchar(20) primary key,
sales real,
capital real,
penalty_charged real,
offersgained real
)

create table expenses(
expensesID varchar(20) primary key,
transport real,
stock_payments real,
rent real,
maintenance_fee real,
food_charges real,
utility_bill real,
salaries real
)
create table report(
reportID varchar(20) primary key,
sales real,
expenses real, 
profit real,
other varchar(40),
expensesID varchar(20),
incomeID varchar(20),
date date,
constraint income_fk foreign key(incomeID) references income(incomeID),
constraint expenses_fk foreign key(expensesID) references expenses(expensesID)
)


create table income(
incomeID varchar(20) primary key,
month varchar(15),
year date,
sales real,
discount_received real,
other real
)

create table expense(
expenseID varchar(20) primary key,
month varchar(15),
year date,
rent real,
salaries real,
utility_bills real,
maintenance_fees real,
food_charges real,
taxes_paid real,
advertising real, 
business_fee real,
machinery real,
transport real,
insurance real,
miscellaneous real,
stocks real
)

create table report(
reportID varchar(20) primary key,
incomeID varchar(20),
expenseID varchar(20),
income real,
expenses real,
month varchar(15),
year date,
capital real,
date date,
profit real,
constraint income_fk foreign key(incomeID) references income(incomeID),
constraint expense_fk foreign key(expenseID) references expense(expenseID)
)

create table allocate(
jobID varchar(20),
vehicle_no varchar(20),
NIC varchar(15),
name varchar(30),
date_of_completion date,
job_description varchar(40),
EID varchar(20),
Emp_name varchar(40),
specialty varchar(30),
constraint allocate_pk primary key(jobID, vehicle_no),
constraint job1_fk foreign key(jobID) references job(jobID),
constraint vehicle1_fk foreign key(vehicle_no) references vehicle(reg_no),
constraint vehicle_owner1_fk foreign key(NIC) references vehicle_owner(NIC),
constraint tech_emp1_fk foreign key(EID) references tech_emp(EID)
)
 
create table otherIncome(
date date,
description varchar(40),
amount real,
no int,
constraint otherIncome_pk primary key(date, no)
)

create table sales(
jobID varchar(20),
NIC varchar(15),
cost_for_parts real,
serivce_charge real,
discount real,
penalty real,
total_charge real,
date1 date,
constraint sales_pk primary key(jobID, date1),
constraint job2_fk foreign key(jobID) references job(jobID),
constraint vehicle_owner2_fk foreign key(NIC) references vehicle_owner(NIC)
)

create table miscellaneous(
no int,
date date,
type varchar(40),
amount real,
constraint miscellaneous_pk primary key(date, no)
)

create table discountReceived(
supID varchar(20),
SID varchar(20),
totalbefore real,
discount_rate real,
discountafter real,
date date,
no int,
constraint discountReceived_pk primary key(supID, no, date),
constraint supplier1_fk foreign key(supID) references suppliers(supID),
constraint sparepart1_fk foreign key(SID) references spareparts(SID)
)

create table machineryCost(
date date,
no int,
type varchar(40),
company varchar(40),
amount real, 
constraint machineryCost_pk primary key(date, no)
)

create table salary(
EID varchar(20) primary key,
basic_salary real,
overTime real,
fine real,
bonus real,
total real,
date date
)

create table utiliy(
no int,
type varchar(40),
company varchar(40),
payment real,
date date,
constraint utility_pk primary key(date, no)
)

create table maintenanceFee(
no int, 
type varchar(40),
amount real, 
date date,
constraint maintenanceFee_pk primary key(no, date)
)


create table foodCharges(
no int,
date date,
company varchar(40),
amount real,
constraint foodCharges_pk primary key(no, date)
)

create table payStock(
date date,
supID varchar(40),
cost real,
discount_gained real,
netAmount real,
constraint payStock_pk primary key(date, supID)
)

create table tax(
no int,
date date, 
type varchar(40),
fines real,
amount real,
constraint tax_pk primary key(date, no)
)

create table receipt(
receiptID varchar(20) primary key,
supID varchar(20),
name varchar(40),
time time,
date date,
grossAmount real,
discount real,
netAmount real,
constraint supplier2_fk foreign key(supID) references suppliers(supID)
)

create table recepitContent(
receiptID varchar(20),
no int,
SID varchar(20),
name varchar(40),
quantity int,
unitPrice real,
totalPrice real,
constraint receiptContent_pk primary key(receiptId, no),
constraint receipt_fk foreign key(receiptID) references receipt(receiptID),
constraint spareparts_fk foreign key(SID) references spareparts(SID)
)
